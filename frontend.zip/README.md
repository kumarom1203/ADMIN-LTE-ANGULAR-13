# index.html 
change body class as per your theme style which is in adminLte page body style
example:
<body class="login-page sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed">
you can keep login-page class here as this required in login page but its not affect other page as login-page class is dedicated to login page only

# in login page click on login you will directly go to dashboard as there is now authentication enabled 



